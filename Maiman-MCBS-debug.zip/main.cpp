#include "mainwindow.h"
#include "interfaces/mainwindowcontrollerinterface.h"

#include <QApplication>
#include "network/networkmodel.h"
#include "network/protocols/modbus.h"
#include "mainviewfacade.h"
#include "model/devicefactory.h"
#include <QTcpSocket>

#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    ////========================
    /// 1. создаем экземпляры парсеров
    ///     а. парсер данных
    ///     б. парсер gui
    /// 2. парсим данные
    /// 3. Создаем экземпляры MainWindow, Controller и Model
    /// 4. передаем данные gui в MainWindow и в DeviceModel
    ////========================

    MainWindow w;
    w.show();

    MainViewFacade* mvCntrl = new MainViewFacade();

    mvCntrl->addView(&w);

    void* parser = nullptr;
    NetworkModel* model = new NetworkModel(new DeviceFactory(parser), new Modbus("modbus"));
    model->addFacade(mvCntrl);

    return a.exec();
}
