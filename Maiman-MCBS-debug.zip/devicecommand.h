#ifndef PARAMETER_T_H
#define PARAMETER_T_H

#include <QObject>
#include <QString>
#include <QVariant>

class DeviceCommand : public QObject
{
    Q_OBJECT
public:
    static const quint16 MAX_COM_INTERVAL_COUNTER;
    explicit DeviceCommand(QString code, QString unit = "", double divider = 1, quint8 interval = 1, bool isTemperature = false, quint16 maxInterval = MAX_COM_INTERVAL_COUNTER, QObject *parent = nullptr);
    virtual DeviceCommand* copy();
    void setTemperatureUnit(QString unit);
    QString getTemperatureUnit();
    QString getCodeStr();
    quint16 getCode();
    virtual double getValue();
    virtual qint16 getIValue();
    virtual quint16 getRawValue();
    bool needToRequest();
    void resetInterval();
    double getDivider();
    virtual bool isSignedValue();
    bool isTemperature();
    QString getUnit();
    virtual quint16 getRawFromValue(double value);

    static double convertCelToFar(double val);
    static double convertFarToCel(double val);

signals:
    void valueChanged();

public slots:
    virtual void setRawValue(quint16 value);

protected:
    quint16 maxInterval;
    QString temperatureUnit;
    QString unit;
    QString codeStr;
    quint16 code;
    double Divider;
    bool isTemperatureFlag;
    QVariant rawValue;
    double value;
    int iValue;
    quint8 interval;
    quint8 tick;
};

#endif // PARAMETER_T_H
