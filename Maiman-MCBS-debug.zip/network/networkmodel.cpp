#include "networkmodel.h"
#include <QDebug>

const quint16 NetworkModel::TIMEOUT_MS = 50*10;
const quint16 NetworkModel::IDENTIFY_REG_ID_DEFAULT = 0x0702; // debug замени

NetworkModel::NetworkModel(DeviceFactory *deviceModelFactory, SoftProtocol* protocol, QObject *parent) : QObject(parent), ProtocolObserverInterface(), ModelInterface()
{
    m_bIsStart = false;
    m_netDevice = protocol;
    m_deviceModelFactory = deviceModelFactory;
    m_deviceModelFactory->start();
//    m_view = vi;
//    m_view->addModel(this);
    m_devices.fill(nullptr, Modbus::MAX_ADDRESS);
}

NetworkModel::~NetworkModel() {
    clear();
}

// controller to model interface overrides

void NetworkModel::start(QIODevice* networkDevice)
{
    if(networkDevice == nullptr) return;

    m_netDevice->setDevice(networkDevice);
    m_netDevice->addObserver(this);
    m_bIsStart = true;

    rescanNetwork();

    // parse a device model file

}

bool NetworkModel::isStart() {
    return m_bIsStart;
}

void NetworkModel::stop()
{
   m_netDevice->removeObserver(this);
   m_netDevice->stop();
   m_bIsStart = false;
   clear();
}

void NetworkModel::setDeviceCommand(quint8 addr, quint16 command, quint16 value)
{
    m_netDevice->setDataValue(addr, command, value);
}

void NetworkModel::rescanNetwork()
{
    clear();
    for(quint8 iAddr = 1; iAddr <= SoftProtocol::MAX_ADDRESS; ++iAddr) {
        m_netDevice->getDataValue(iAddr, NetworkModel::IDENTIFY_REG_ID_DEFAULT);
    }
}

void NetworkModel::addFacade(MainViewFacade* facade) {
    m_view = facade;
}

// modbus interface overrides

void NetworkModel::dataNotify(quint8 addr, quint16 reg, quint16 value)
{
    if(reg == NetworkModel::IDENTIFY_REG_ID_DEFAULT) initDevice(addr, value);
    dataReady();
}

void NetworkModel::dataReady()
{
    // request a new value
}

// private methods
void NetworkModel::clear() {
    for(auto *item : m_devices) {
        delete item;
    }
    m_devices.clear();
    m_devices.fill(nullptr, Modbus::MAX_ADDRESS);
}

void NetworkModel::initDevice(quint8 addr, quint16 id)
{
    qDebug() << "Init device " << addr << " with id " << id;
    Device* newDevice = m_deviceModelFactory->createDevice(id);
    if(newDevice != nullptr) qDebug() << newDevice->name();

    if(addr < m_devices.size()) {
//        Device* currDev = m_devices.at(addr);
//        if(currDev != nullptr) {
//            delete currDev;
//        }
        m_devices.insert(addr, newDevice);
    }
}
