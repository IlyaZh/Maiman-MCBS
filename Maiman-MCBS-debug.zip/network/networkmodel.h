#ifndef NETWORKMODEL_H
#define NETWORKMODEL_H

#include <QObject>
#include <QPointer>
#include <QIODevice>
#include <QVector>
#include "protocols/modbus.h"
#include "interfaces/ProtocolObserverInterface.h"
#include "model/ModelInterface.h"
#include "SoftProtocol.h"
#include "devicemodel.h"
#include "model/devicefactory.h"
#include "mainviewfacade.h"

//#include "enums.h"

class MainViewFacade;

class NetworkModel : public QObject, ProtocolObserverInterface, public ModelInterface
{
    Q_OBJECT
public:
    static const quint16 IDENTIFY_REG_ID_DEFAULT;
    static const quint16 TIMEOUT_MS;
    explicit NetworkModel(DeviceFactory *deviceModelFactory, SoftProtocol* protocol, QObject *parent = nullptr);
    ~NetworkModel();
    void start(QIODevice* iodevice) override;
    bool isStart() override;
    void stop() override;
    void setDeviceCommand(quint8 addr, quint16 command, quint16 value) override;
    void rescanNetwork() override;
    void addFacade(MainViewFacade* facade);

    void dataNotify(quint8 addr, quint16 reg, quint16 value) override;
    void dataReady() override;
signals:
    void modelConnected(bool);

public slots:
private slots:


private:
    DeviceFactory *m_deviceModelFactory;
    MainViewFacade* m_view;
    SoftProtocol* m_netDevice;
    QVector<Device*> m_devices;
    bool m_bIsStart;


    void clear();
    void initDevice(quint8 addr, quint16 id);
};


#endif // NETWORKMODEL_H
