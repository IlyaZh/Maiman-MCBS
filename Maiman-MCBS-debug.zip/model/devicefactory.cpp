#include "devicefactory.h"
#include <QDebug>

DeviceFactory::DeviceFactory(void* abstractParser, QObject* parent) : QObject(parent), m_parser(abstractParser) {

}

DeviceFactory::~DeviceFactory() {
//    m_parser->stop();
}

void DeviceFactory::start() {
    m_thread = new QThread();

//    m_parser->moveToThread(m_thread);

//    connect(m_thread, SIGNAL(started()), m_parser, SLOT(process()));
//    connect(m_parser, SIGNAL(finished()), m_thread, SLOT(quit()));
//    connect(m_parser, SIGNAL(finished()), this, SLOT(parsingFinished()));
//    //connect(...,m_parser, SLOT(stop()));
//    //connect(m_parser, SIGNAL(finished()), m_parser, SLOT(deleteLater()));
//    connect(m_thread, SIGNAL(finished()), m_thread, SLOT(deleteLater()));
//    m_thread->start();

    // for debug only
    QVector<DeviceCommand*>* devCmd = new QVector<DeviceCommand*>();
    devCmd->append(new DeviceCommand("0001", "Гц", 10, 1));
    devCmd->append(new DeviceCommand("0011", "Гц", 10, 1));
    devCmd->append(new DeviceCommand("0012", "Гц", 10, 1));
    devCmd->append(new DeviceCommand("0002", "мс", 10, 1));
    devCmd->append(new DeviceCommand("0021", "мс", 10, 1));
    devCmd->append(new DeviceCommand("0022", "мс", 10, 1));
    devCmd->append(new DeviceCommand("0003    ", "А", 10, 1));
    devCmd->append(new DeviceCommand("0031", "А", 10, 1));
    devCmd->append(new DeviceCommand("0032", "А", 10, 1));

    QVector<DeviceBinaryOption*>* devBin = new QVector<DeviceBinaryOption*>();
    devBin->append(new DeviceBinaryOption("Start\\stop",
                                          new DeviceCommand("0007", "", 1, 1),
                                          0x0008,
                                          0x0010,
                                          0x0001));

    DeviceModel* dev = new DeviceModel(16,
                                       "SF6100 v1",
                                       new DeviceDelays(200, 10, 1000),
                                       new DeviceDescription(nullptr, "Device wtf", "http://yandex.ru"),
                                       devCmd,
                                       devBin);
    m_DeviceModels.append(dev);
}

Device* DeviceFactory::createDevice(quint16 id) {
    DeviceModel* devModel = findModel(id);
    if(devModel == nullptr) {
        qDebug() << "Device model with id =" << id << "has not found!";
        return nullptr;
    } else {
        return devModel->createDevice();
    }
}


// private slots
void DeviceFactory::parsingFinished() {
//    if(m_parser->hasError()) {

//    } else {

//    }
}

// private methods
DeviceModel* DeviceFactory::findModel(quint16 id) {
    for(DeviceModel *device : m_DeviceModels) {
        if(device->id() == id) {
            return device;
        }
    }

    return nullptr;
}
