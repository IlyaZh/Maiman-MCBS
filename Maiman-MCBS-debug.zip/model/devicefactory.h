#ifndef DEVICEMODELFACTORY_H
#define DEVICEMODELFACTORY_H

#include "devicemodel.h"
#include "device.h"
#include <QThread>
#include <QObject>


class DeviceFactory : public QObject
{
    Q_OBJECT
public:
    DeviceFactory(void* abstractParser, QObject *parent = nullptr);
    ~DeviceFactory();
    void start();
    Device* createDevice(quint16 id);

private slots:
    void parsingFinished();
private:
    void* m_parser;
    QThread* m_thread;
    QVector<DeviceModel*> m_DeviceModels;

    DeviceModel* findModel(quint16 id);


};

#endif // DEVICEMODELFACTORY_H
