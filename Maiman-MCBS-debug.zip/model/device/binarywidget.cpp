#include "binarywidget.h"

BinaryWidget::BinaryWidget(DeviceBinaryOption* pOption) : option(pOption)
{

}

QWidget BinaryWidget::widget() {

}

// private slots
void BinaryWidget::buttonClicked(bool newState) {

}
