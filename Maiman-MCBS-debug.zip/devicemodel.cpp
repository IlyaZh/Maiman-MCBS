#include "devicemodel.h"

DeviceModel::DeviceModel(quint16 id, QString name, DeviceDelays *delays, DeviceDescription *description, QVector<DeviceCommand*> *commands, QVector<DeviceBinaryOption*> *binaryOptions) :
    m_Id(id),
    m_Name(name),
    m_Delays(delays),
    m_Description(description),
    m_Commands(commands),
    m_BinaryOptions(binaryOptions)
{}

DeviceModel::~DeviceModel() {
    if(m_Delays != nullptr) delete m_Delays;
    if(m_Description != nullptr) delete m_Description;

    for(DeviceCommand* item : *m_Commands) delete item;
    if(m_Commands != nullptr) delete m_Commands;

    for (DeviceBinaryOption* item : *m_BinaryOptions) delete item;
    if(m_BinaryOptions != nullptr) delete m_BinaryOptions;
}

Device* DeviceModel::createDevice()
{
    QVector<DeviceCommand*> *commands = new QVector<DeviceCommand*>();
    for(DeviceCommand* cmd : *m_Commands) {
        commands->append(cmd->copy());
    }

    QVector<DeviceBinaryOption*> *binOptions = new QVector<DeviceBinaryOption*>();
    // Переделай на DeviceBibaryWidget
    for(DeviceBinaryOption* option : *m_BinaryOptions) {
        binOptions->append(option->copy());
    }
    return new Device(m_Id, m_Name, m_Delays, m_Description, commands, binOptions);
}

QString DeviceModel::name() { return m_Name; }

quint16 DeviceModel::id() { return m_Id; }
