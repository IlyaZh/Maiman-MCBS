#ifndef DEVICE_H
#define DEVICE_H

#include <QObject>
#include "devicecommand.h"
#include "devicebinaryoption.h"
#include "devicemodel.h"
#include "model/device/binarywidget.h"

class DeviceDelays;
class DeviceDescription;
class DeviceModel;

class Device : public QObject
{
    Q_OBJECT
public:
    explicit Device(quint16 id, QString name, DeviceDelays *delays, DeviceDescription *description, QVector<DeviceCommand*> *commands, QVector<DeviceBinaryOption*> *binaryOptions, QObject *parent = nullptr);
    void setData(quint16 reg, quint16 value);
    QString name();
    quint16 id();

private:
    quint16 m_Id;
    QString m_Name;
    DeviceDelays* m_Delays;
    DeviceDescription* m_Description;
    QVector<DeviceCommand*> *m_Commands;
    QVector<DeviceBinaryOption*> *m_BinaryOptions;
    QVector<BinaryWidget*> m_BinaryWidgets;

signals:

};

#endif // DEVICE_H
