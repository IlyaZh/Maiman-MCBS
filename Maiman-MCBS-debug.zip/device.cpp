#include "device.h"

Device::Device(quint16 id, QString name, DeviceDelays *delays, DeviceDescription *description, QVector<DeviceCommand*> *commands, QVector<DeviceBinaryOption*> *binaryOptions, QObject *parent)
    : QObject(parent),
    m_Id(id),
    m_Name(name),
    m_Delays(delays),
    m_Description(description),
    m_Commands(commands),
    m_BinaryOptions(binaryOptions)
{
    for(DeviceBinaryOption* item : *m_BinaryOptions) {
        m_BinaryWidgets.append(new BinaryWidget(item));
    }
}

void Device::setData(quint16 reg, quint16 value) {
    for(DeviceCommand* cmd : *m_Commands) {
        if(cmd->getCode() == reg) {
            cmd->setRawValue(value);
        }
    }
}

QString Device::name() {
    return m_Name;
}

quint16 Device::id() {
    return m_Id;
}
