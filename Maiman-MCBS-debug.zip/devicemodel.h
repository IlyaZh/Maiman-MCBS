#ifndef DEVICEMODEL_H
#define DEVICEMODEL_H

#include <QObject>
#include "devicecommand.h"
#include "devicebinaryoption.h"
#include "device.h"

class Device;

class DeviceDelays {
public:
    DeviceDelays(quint16 stopDelayMs, quint16 minCommandDelayMs, quint16 maxCommandDelayMs)
        : m_stopDelayMs(stopDelayMs),
          m_minCommandDelayMs(minCommandDelayMs),
          m_maxCommandDelayMs(maxCommandDelayMs)
    {}
    quint16 stopDelayMs() { return m_stopDelayMs; }
    quint16 minCommandDelayMs() { return m_minCommandDelayMs; }
    quint16 maxCommandDelayMs() { return m_maxCommandDelayMs; }
private:
    quint16 m_stopDelayMs;
    quint16 m_minCommandDelayMs;
    quint16 m_maxCommandDelayMs;
};

class DeviceDescription
{
public:
    DeviceDescription(QPixmap *pic, QString desc, QString link) : m_Photo(pic), m_Description(desc), m_Link(link) {}
    ~DeviceDescription() {
        if(m_Photo != nullptr) { delete m_Photo; }
    }
    const QPixmap* photo() { return m_Photo; }
    QString description() { return m_Description; }
    QString link() { return m_Link; }
private:
    QPixmap* m_Photo;
    QString m_Description;
    QString m_Link;
};

class DeviceModel
{
public:
    DeviceModel(quint16 id, QString name, DeviceDelays *delays, DeviceDescription *description, QVector<DeviceCommand*> *commands, QVector<DeviceBinaryOption*> *binaryOptions);
    ~DeviceModel();
    Device* createDevice();
    QString name();
    quint16 id();

private:
    quint16 m_Id;
    QString m_Name;
    DeviceDelays* m_Delays;
    DeviceDescription* m_Description;
    QVector<DeviceCommand*> *m_Commands;
    QVector<DeviceBinaryOption*> *m_BinaryOptions;
};

#endif // DEVICEMODEL_H
